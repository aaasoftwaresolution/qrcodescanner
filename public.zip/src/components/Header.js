import React from "react";

export default function Header() {
  return (
    <div>
      <div className="container2 d-flex justify-content-center">
        <img
          className="img-fluid"
          src="images/header.jpg"
          alt="restaurant bg"
        />
      </div>
    </div>
  );
}
